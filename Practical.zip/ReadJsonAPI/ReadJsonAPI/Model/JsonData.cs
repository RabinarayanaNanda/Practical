﻿namespace ReadJsonAPI.Model
{
    public class JsonData
    {
        
        public string Name { get; set; }
        public string Category { get; set; }
        public string Type { get; set; }
        public Colors Code { get; set; }
        

    }
    public class Colors
    {
        public int[] RGBA { get; set; }
        public string Hex { get; set; }
        
    }
}
