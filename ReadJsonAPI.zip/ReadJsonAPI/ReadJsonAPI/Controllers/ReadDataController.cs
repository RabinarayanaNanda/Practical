﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ReadJsonAPI.Model;

namespace ReadJsonAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReadDataController : ControllerBase
    {
        //api:Get
        public async Task<IEnumerable<JsonData>> GetJsonData()
        {
            var webClient = new WebClient();
            var allText = webClient.DownloadString(@"D:\Practical Test\ReadJsonAPI\ReadJsonAPI\wwwroot\Jsonfile\data.json");            
            var jsonObject = JsonConvert.DeserializeObject<List<JsonData>>(allText);           
            return jsonObject;
        }

    }
}
